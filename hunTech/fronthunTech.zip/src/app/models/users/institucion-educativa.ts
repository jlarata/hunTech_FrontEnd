import { User } from "./user";

export class InstitucionEducativa extends User {
    //nombre: string;
}
