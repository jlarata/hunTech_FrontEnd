import { User } from "./user";

export class Gerente extends User {
    id_proyecto?: string;    
}
