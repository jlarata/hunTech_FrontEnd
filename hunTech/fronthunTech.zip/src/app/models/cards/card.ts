export class Card {
    titulo?: string;
    descripcion?: string;
}